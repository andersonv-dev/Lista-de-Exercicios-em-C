#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int i,opc,software = 0,hardware = 0,rede = 0,atendimentos = 0;
	
	for (i = 1; i <=10; i++){
		
		printf("=========TIPO DE CHAMADO=========\n");
		printf("1- Software\n");
		printf("2- Hardware\n");
		printf("3- Rede\n");
		printf("0- Encerrar\n");
		
		printf("Digite a op��o desejada: \n");
		scanf("%d",&opc);
		
		if(opc == 0){
			break;
		}
		
		switch (opc){
			case 1:
				printf("Suporte de Software selecionado...\n");
				break;
			case 2:
				printf("Suporte de Hardware selecionado...\n");
				break;
			case 3:
				printf("Suporte de Rede selecionado...\n");
				break;
			default:
				printf("Op��o inv�lida!\n");
				continue;
				
		}
		
		if(opc == 1){
			software++;
		}else if(opc == 2){
			hardware++;
		}else if(opc == 3){
			rede++;
		}
			
		printf("======Relatorio======\n");
		printf("Software: %d\n",software);
		printf("Hardware: %d\n",hardware);
		printf("Rede: %d\n",rede);
		printf("Total de atendimentos: %d\n",i);
	}
	
	
	return 0;
}
