#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int num,opc;
	

	printf("Digite um numero inteiro (ou 0 para finalizar)\n");
	scanf("%d",&num);
	
	while (num != 0){
		
		
		printf("Digite o numero desejado: (ou 0 para finalizar)\n");
		scanf("%d",&num);
		
	
		
		
	}
	
	
	return 0;
}
