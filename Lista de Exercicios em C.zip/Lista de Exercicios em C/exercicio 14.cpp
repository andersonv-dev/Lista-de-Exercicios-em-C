#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int opc;
	
	do{
		printf("=============MENU=============\n");
		printf("1- Software\n");
		printf("2- Hardware\n");
		printf("3- Rede\n");
		printf("0- Encerrar\n");
		
		printf("Digite a op��o desejada: \n");
		scanf("%d",&opc);
		
		switch (opc){
			case 1:
				printf("Suporte de Software selecionado...\n");
				break;
			case 2:
				printf("Suporte de Hardware selecionado...\n");
				break;
			case 3:
				printf("Suporte de Rede selecionado...\n");
				break;
				
		}
	} while(opc != 0);
		printf("Encerrando sistema...\n");
	
	
	return 0;
}
