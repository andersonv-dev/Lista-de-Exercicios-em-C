#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int i,funciona = 0,defeito = 0,opc;
	
	for (i = 1; i <= 10; i ++){
		printf("O computador %d esta funcionando?\n",i);
		printf("1- Funcionando\n");
		printf("0- Com defeito\n");
		scanf("%d",&opc);
		
		switch (opc){
			
			case 1:
				funciona ++;
				break;
			case 0:
				defeito ++;
				break;
		}
	}
	
	printf("=====Relatorio de funcionamento=====\n");
	printf("Computadores funcionando: %d\n",funciona);
	printf("Computadores com defeito: %d\n",defeito);
	
	return 0;
}
