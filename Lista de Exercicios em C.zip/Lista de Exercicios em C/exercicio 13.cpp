#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int opc;
	
	do{
		printf("=============MENU=============\n");
		printf("1- Cadastrar\n");
		printf("2- Consultar\n");
		printf("3- Relatorio\n");
		printf("0- Encerrar\n");
		
		printf("Digite a op��o desejada: \n");
		scanf("%d",&opc);
		
		switch (opc){
			case 1:
				printf("Cadastrando usuario...\n");
				break;
			case 2:
				printf("Consultando...\n");
				break;
			case 3:
				printf("Relatorio...\n");
				break;
				
		}
	} while(opc != 0);
		printf("Encerrando sistema...\n");
	
	
	return 0;
}

