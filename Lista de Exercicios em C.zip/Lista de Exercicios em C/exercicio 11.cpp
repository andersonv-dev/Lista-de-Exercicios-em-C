#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int num;

do{
	printf("Digite um numero inteiro:");
	scanf("%d",&num);
	
}while (num <0); {
		
	if(num <0){
	printf("numero negativo");
	} else {
		printf("numero positivo");
	}
	}

	
	
	return 0;
}
