#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int idade;
	
	do{
		printf("Digite sua idade: \n");
		scanf("%d",&idade);
		
	} while (idade <0);
	printf("Idade valida");

	
	return 0;
}

