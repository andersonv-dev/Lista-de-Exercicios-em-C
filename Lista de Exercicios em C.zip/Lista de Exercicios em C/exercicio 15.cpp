#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	
	int codigo,prioridade,i,qtd;
	
	printf("Digite quantos chamados deseja cadastrar: \n");
	scanf("%d",&qtd);
	
	for(i = 1; i <= qtd; i ++){
		
	printf("Codigo do chamado %d: \n",i);
	scanf("%d",&codigo);
	
	do{
		printf("=-=-=-=-=-=Prioridade=-=-=-=-=-=\n");
		printf("1 - Urgente\n");
		printf("2 - Prioritario\n");
		printf("3 - Normal\n");
		scanf("%d",&prioridade);
	}while(prioridade <1 || prioridade >3);
	
	if(prioridade == 1){
		printf("Prioridade: Urgente!!\n");
	} else if (prioridade == 2){
		printf("Prioridade: Prioritario!\n");
	} else if (prioridade == 3){
		printf("Prioridade: Normal\n");
	}
	
}
	return 0;
}

