#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int qtd,i;
	float nota;
	
	printf("Digite quantos estudantes receberam nota: \n");
	scanf("%d",&qtd);
	
	for(i = 1; i <= qtd; i++){

		printf("A nota do %d aluno �: \n",i);
		scanf("%f",&nota);
		
		if(nota >= 7){
			printf("A nota foi maior ou igual a 7!\n");
		}else{
			printf("A nota foi menor que 7!");
		}
		
	}
	
	
	
	
	return 0;
}
