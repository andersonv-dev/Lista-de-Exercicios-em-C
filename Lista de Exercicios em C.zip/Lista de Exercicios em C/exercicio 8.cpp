#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int num,i;
	
	printf("Digite 10 numeros inteiros:\n");
	
	for(i = 1; i <= 10; i ++ ){
		
		printf("Digite o %d numero: \n",i);
		scanf("%d",&num);
		
		if(num == 0){
			printf("ZERO\n");
		} else if (num > 0) {
			printf("POSITIVO\n");
		} else if (num < 0) {
			printf("NEGATIVO\n");
		}
		
	}
	
	
	
	return 0;
}
