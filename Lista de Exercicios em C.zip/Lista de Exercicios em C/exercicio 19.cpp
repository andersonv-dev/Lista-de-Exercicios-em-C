#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	float valor,valorTotal = 0;
	int i;
	
	for(i = 1; i <= 5; i++){
		printf("Digite o valor da compra %d:\n",i);
		scanf("%f",&valor);
		
		valorTotal = valorTotal+valor;
	}
	printf("Valor total das vendas: R$ %.2f\n",valorTotal);
	
	return 0;
}
