#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int senha;

while (senha != 1234){
	
	printf("Digite a senha: \n");
	scanf("%d",&senha);
	
	if(senha == 1234){
		printf("Acesso Permitido\n");
	} else {
		printf("Acesso Negado\n");
	}
}
	
	return 0;
}
