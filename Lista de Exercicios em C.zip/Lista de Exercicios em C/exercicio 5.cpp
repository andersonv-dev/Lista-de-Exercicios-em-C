#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int num,resultado,i;
	
	printf("Qual tabuada desejada de 1 a 10: ");
	scanf("%d",&num);
	
	for(i = 1; i <= 10; i++){
		(resultado = num * i);
	printf("%d x %d = %d\n",i,num,resultado);
	
	}

	
	
	return 0;
}
