#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int codigo,qtd,i;
	float preco;
	printf("Quantos produtos deseja cadastrar: \n");
	scanf("%d",&qtd);
	
	for(i = 1; i <= qtd; i++){
		
		printf("Digite o pre�o do produto %d :\n",i);
		scanf("%f",&preco);
		
		printf("Digite o codigo do produto %d :\n",i);
		scanf("%d",&codigo);
		
		printf("Produto %d cadastrado!\n",i);
		printf("Pre�o do produto: R$ %.2f\n",preco);
		printf("Codigo do produto: %d\n",codigo);
	}
	
	
	
	
	
	return 0;
}
