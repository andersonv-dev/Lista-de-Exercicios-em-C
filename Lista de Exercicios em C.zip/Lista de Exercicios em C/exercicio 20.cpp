#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL,"");
	int opcTipo,opcPrioridade,codigo,opcSistema;
	int software=0,hardware=0,rede=0,urgente=0,chamados=0;
	

	
	
	do{
	
		printf("========SISTEMA DE SUPORTE========\n");
		printf("1- Registrar chamado\n");
		printf("2- Relatorio\n");
		printf("0- Sair\n");
		scanf("%d",&opcSistema);
		
		if(opcSistema == 0){
			break;}
		
		switch(opcSistema){
		
		case 1:
		chamados ++;
		
		printf("=========TIPO DE CHAMADO=========\n");
		printf("1- Software\n");
		printf("2- Hardware\n");
		printf("3- Rede\n");
		
		printf("Digite a op��o desejada: \n");
		scanf("%d",&opcTipo);
		
		
		
		
		switch (opcTipo){
			case 1:
				printf("Suporte de Software selecionado...\n");
				software ++;
				break;
			case 2:
				printf("Suporte de Hardware selecionado...\n");
				hardware ++;
				break;
			case 3:
				printf("Suporte de Rede selecionado...\n");
				rede ++;
				break;
			default:
				printf("Op��o inv�lida!\n");
				continue;
				
		}
		
		printf("Digite o codigo do Chamado: \n");
		scanf("%d",&codigo);
		
		printf("=========PRIORIDADE=========\n");
		printf("1 - Urgente\n");
		printf("2 - Prioritario\n");
		printf("3 - Normal\n");
		
		printf("Digite a op��o de Prioridade:");
		scanf("%d",&opcPrioridade);
		
		switch(opcPrioridade){
			case 1:
				printf("Prioridade: Urgente!!\n");
				urgente ++;
				break;
			case 2:
				printf("Prioridade: Prioritario!\n");
				break;
			case 3:
				printf("Prioridade: Normal.\n");
				break;
			default:
				printf("Prioridade inv�lida inserida.\n");
		}
		
		break;
		
		
		printf("==========RELATORIO DO CHAMADO=========\n");
		printf("Codigo: %d\n",codigo);
		
		if(opcTipo == 1){
			printf("Tipo: Software\n");
		} else if(opcTipo == 2){
			printf("Tipo: Hardware\n");
		} else if(opcTipo == 3){
			printf("Tipo: Rede\n");
		}
		
		if(opcPrioridade == 1){
			printf("Prioridade: Urgente!!\n");
		} else if(opcPrioridade == 2){
			printf("Prioridade: Prioritario!\n");
		} else if(opcPrioridade == 3){
			printf("Prioridade: Normal.\n");
		}
		
	case 2:
		printf("==========RELATORIO DOS CHAMADOS=========\n");
		printf("Chamados de Software: %d\n",software);
		printf("Chamados de Hardware: %d\n",hardware);
		printf("Chamados de Rede: %d\n",rede);
		printf("Chamados Urgentes: %d\n",urgente);
		printf("Total de chamados: %d\n",chamados);
	}
	}
	
	 while(opcSistema != 0);
		printf("Encerrando sistema...\n");
		return 0;
}

	

